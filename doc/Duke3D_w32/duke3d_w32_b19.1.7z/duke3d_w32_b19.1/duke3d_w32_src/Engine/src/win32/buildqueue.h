#ifndef _BUILD_QUEUE_
#define _BUILD_QUEUE_

class BuildQueue
{
	public:
		BuildQueue()
		{}
		
		~BuildQueue()
		{}
		void Nothing()
		{
		}
};

#endif