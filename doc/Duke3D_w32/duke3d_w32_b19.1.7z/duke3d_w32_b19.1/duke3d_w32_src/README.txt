Release: Build 19.1
Date: 4/24/2004 2:50pm PST

The homepage for this port is:
http://www.rancidmeat.com/project.php3?id=1

The official irc channel for this port is:
irc.homelan.com #DukeNukem

-dave

Special Thanks to Adrian "JimCamel" Clark, and Ahmed Rasool for contributing
new console variables and commands. And Thanks to "Worsel"for helping debug
the Joystick issues. Thanks to AddFaz for networking changes, and auto-aim toggle.
Thanks the Spem for the joystick testing.

---------------------
Build notes:
---------------------
Build 19.1
* Modified optimization compiler flags in VC6 projects.
* Fixed game_dir option
* Fixed issues with flying pig cops not moving.

Build 19
* Added .ogg/.s3m/.mod/.it/.xm/.wav/.mp3 Music playback support
  (mp3 playback is pretty crappy. I blame the smpeg lib)
* Improved performance. (breaks old .dmo files.. enjoy the new ones) 
* Added new 2 player stable networking. (-netmode_stable) 
* Included initial version of Setup_w32. (does very little currently)
* "Fixed" blimp crash in multiplayer.
* Fixed a console crash when pressing the down arrow.
* Made a few changes to SDL lib so that the renderer does not need 
  to be set via environment variables.


Build 18.5(alpha development build)
* This build incorporates new experimental networking.

Build 18.4(development build)
* Added support for DukesterX's stun server feature. This should help those behind
  firewalls. (thx AddFaz)

Build 18.3(development build)
* Added screenshot functionality back in. This had been on the TODO list for a while.
  It now saves out a 24-bit BMP in the game directory. (F12 to take a screenshot)

Build 18.2(development build)
* Opening the console now pauses the game for singleplayer games.
* Added -game_dir commandline param for mods/total conversions. 
  This attempts to load all resources from the specified game directory.
  It will fallback to the main root dir if missing resources.
  It has been tested with the "Alienz TC" and "Duke LA" Total conversions.
  Saved games are saved to the game_dir.

Example use of each: 
  Alienz TC
  duke3d_w32.exe -game_dir mods\alienztc

  Duke L.A.
  duke3d_w32.exe -game_dir mods\dukela /xLAGame.DM /gdla.prg

  To download these or other TCs, check out: 
  http://www.planetduke.com/duke3/files/tc_1.shtml

  You simply need to make a directory to stick the TCs files in. I recommend \duke3d_w32\mods\<Your TC>

*NOTE: this release is not intended as an official release. It's simply for the 
       amusment of those who wish to be amused. It has not undergone the standard
       brute force testing. So, feel free to check it out, but it may not act as
       expected. If you notice any odd behavior, let me know. If you run into problems 
       with this version, you can simply revert to Build 18.1. 


Build 18.1
* Fixed an issue with joystick support. (ie. the buttons and hats were unresponsive)
* Fixed an issue with ControllerType 7 breaking smooth mouse.

Build 18
* Changed input to allow the original functionality. (ie. two keys per command)
* Fixed the input bug in which the keyboard mouse and joystick would fight causing
  users to not have the ability to bind one command to the both the keyboard AND mouse.
  This was most apparent on the mouse wheel when trying to bind it to next/prev weapon.
* Changed Console to allow for user to bind it to any key, rather than forcing the tilde.
* Mouse now works in the menu.
* Autoaim can now be toggled via the console.
* New router fixes to the net code.
* Integrated automatic optimal renderer selection based on windowed versus fullscreen.
  (windib vs. directx)
* When connecting to a NET game, custom maps are now started immediately, instead of dropping 
  into a setup screen. This fixes the issue where players would accidentally hit "start" 
  instead of "custom map" thus launching episode 1 instead of the custom map. 
* Markers are also disabled automatically for network games. This is done for network
  integrity/stability/bandwidth consumption. This may change when network code stability is
  more mature.

Build 17.9.3(patch)
* Fixed annoying reverb bug. (This would cause an infinite sound hiccup)
* Added "DebugSound" console variable

Build 17.9.2(patch)
* Fixed crash with sloping walls.
* Fixed crash with sound system. (feel free to use EnableCubic once again)
* Changed console Up/Down arrow to loop through the commands you entered.
* Added "Sensitivity" console variable for non-smooth mouse sensitivity. (thx Chris Marsh)
* Added "TickRate" console variable. (default = 120)
* Added "TicksPerFrame" console variable. (default = 26)
!! These last two console variables control the speed of the game.
   The formula is this: TickRate/TicksPerFrame. You should keep a 4:1 ratio
   to ensure that the demo playback is not broken. If you toy with these
   during a network game, you'll most likely go out of sync really quick.
!! Also, make sure that TicksPerFrame is never larger than TickRate. 

Build 17.9.1(patch)
* Added "top hat" support for Joysticks
* Fixed a crash with swinging doors where the associated sprite index was looking for -1.
* <alt-enter> crash should be fixed.

Build 17.9
* Fixed ControllerType=1(keyboard + mouse) problem. Mouse would move player forward when in mouse aim mode.
* Added a smooth mouse mode.(Experimental)
* Added cvars to support the new mouse mode.
  ->EnableSmoothMouse 1 = enables smooth mouse. This is the default.
  ->SmoothMouseSensX 15000 = Sets the sensitivity of the X axis while in smooth mouse mode. 
  ->SmoothMouseSensY 15000 = Sets the sensitivity of the Y axis while in smooth mouse mode. 

Build 17.8-5
* Fixed issue with fullscreen mode.

Build 17.8
* Fixed Mouse-flip for ControlType 2 and 7.
* Fixed Analog issue for joystick axis 0 and 1.
* Fixed issue where analog mouse settings were over writing the joystick
  settings.

Build 17.7
* Fixed "ControlType 7(joystick + mouse)" problems. Keyboard input should work in 
  mode 7 as well.
! Currently you can not bind the same function (ie. shoot, jump) to a 
  mouse/joystick/keyboard button. I will be fixing that. I don't anticipate that being
  a huge problem for people. It's more of an annoyance. It shouldn't affect too many 
  folks.

Build 17.6
* Fixed(hack-fix) Joystick problem where one could not properly move with joystick when
  in mouse-look mode. (I will probably make a nicer fix for this later)
* Re-implemented "analog_lookingupanddown" axis type for joysticks to use for looking
  up and down.

Build 17.5 Bug fixes
* Fixed the ugly bug where "JoystickAnalogScale" was not being save in the config.
* Added a joystick value debug cvar. "DebugJoystick 1"

Build 17
* New Windows help file version of the docs
* Added "TransConsole" CVAR
* Added validation to "Level" command for the 1.5 data
* Fixed WinMidi to allow users to change which midi device is used via duke3d.cfg. 
  ->Change the "MusicDevice" variable to match your device. Most users will want this setting:
    "MusicDevice = 0"
* Added command line option for fullscreen. "-fullscreen"
* Joystick support! And the addition of a Joystick+Mouse configuration. 
  ->Please read the duke3d_w32.chm for more information. (the input section)


Build 16
* Integrated fixed sound code from kode54. (yay 48000hz!)
* Fixed crash on Area51 demo.
* Added many console variables
* Fixed duke3d.cfg handling of negative numbers. 
  ->(bug would cause duke not to run if there negative numbers in the duke3d.cfg)
* Added new autoexec.cfg system. This will allow you to auto-run commands in the 
  console at startup. One main reason for this is to allow folks to run "classic"
  mode without needing to type that into the console everytime they run the game.
* Added transparency to the console. (Thanks for the tip Cyborg)


Build 15
* Fixed a small console rendering bug. (caused by different resolutions)

Build 14
* Added brand new drop down console.
  ->Read console.txt for information.

Build 13
* Fixed demo playback for 1.4 demos (I hope)
* Integrated new Icculus networking changes. 
  ->Updated networking.txt 
* Integrated several other Icculus fixes. (for case-insensitivity etc.)

Build 12
* Fixed the demo playback for the original demo (Atomic Edition)
  ->(Thanks to Andy Hill)
* Updated the duke3d.cfg default keyboard config to be a little less goofy.
* Integrated a few small Icculus port updates.

Build 11
* Integrates the lastest Icculus changes
* Currently not using the latest networking code off the Icculus CVS.
  -> It's broken on win32, so I didn't integrate it.
  -> I need to look into that. For now net play between
  -> two players works in this build.
* Added some player maps tht I and a friend worked on back in 
  -> the day. Also included some maps we used to play frequently.

Build 10
* Integrated new Audiolib-based sound system. 
  Fixes the sound lag issues
  Fixes the sound pitch issue
  Fixes the sound cutting out issue.
  Kudos to Icculus.org

Build 9
* Improved VOC sampling.
* TCP/IP networked games 
  -Not optimized for internet play.
  -Lan games work pretty well though.

Build 8
* Can load .GRP files for Shareware, 1.3, and Atomic Edition
  So no more need for extracting the data files first. The .GRP is all you need.

Build 7
* Odd movement of some platforms in the game(ie. secret rocket launcher E1L1) is fixed.
* New Icculus code merged.

Build 6
* Sounds now cache after being played once. This fixes the sound lag bug.
  I'm going to look into having all sounds simply pre-cache upon level load. (maybe)
* Integrated the latest Icculus cvs code.
* I left the win_midi code in since there are some bugs with the midi playpack
  in the SDL port.
* Fixed the crash on exit bug in scriplib(Thanks to Icculus)

---------------------
HOWTO get it running:
---------------------

1. copy your duke3d.grp into the "bin" directory.
2. run duke3d_w32.exe

Hint: you can run custom maps like so:
duke3d_w32.exe -map spaceprt.map

Networked play using TCP/IP:
read the duke3d_w32.chm doc.


-------------------------------
HOWTO get the source compiling:
-------------------------------

There are Visual Studio 6.0 and 7.0(.NET) projects avaiable.

You need the SDL lib and the SDL_mixer lib. They must be unzip
to the same directory level. 
For Example:

proj/
    duke3d_w32/
    SDL-1.2.5/
    SDL_mixer-1.2.5/

The other option is to change the source include, and lib 
include paths to match your SDL installation.

You will also have to grab my changes to SDL 1.2.5 in order to compile.

Basically I assume you know how to use Visual Studio.. So I hope you do.


------
Links:
------

libSDL                    
  - http://www.libsdl.org
SDL_mixer                 
  - http://www.libsdl.org/projects/SDL_mixer/
Icculus Duke3d Linux port 
  - http://icculus.org/duke3d/
Another win32 port:
  - http://www.shacknews.com/ja.zz?id=7144651




