#ifndef _GAME_H_
#define _GAME_H_

//extern char game_dir[512];
char* getgamedir();

#endif  // include-once header.

