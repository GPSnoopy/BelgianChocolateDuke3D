#ifndef __joystick_h
#define __joystick_h
#ifdef __cplusplus
extern "C" {
#endif

void   JOYSTICK_UpdateHats( void );

#ifdef __cplusplus
};

#endif
#endif /* __joystick_h */