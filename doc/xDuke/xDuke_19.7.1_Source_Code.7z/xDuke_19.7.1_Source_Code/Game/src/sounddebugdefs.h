#ifndef _SOUND_DEBUG_DEFS_H_
#define _SOUND_DEBUG_DEFS_H_

extern unsigned long sounddebugActiveSounds;
extern unsigned long sounddebugAllocateSoundCalls;
extern unsigned long sounddebugDeallocateSoundCalls;

#endif